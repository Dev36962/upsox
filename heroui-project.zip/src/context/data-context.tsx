import React from 'react';

interface DataContextType {
  data: any;
  loading: boolean;
  error: string | null;
  isConnected: boolean;
  connect: () => void;
  disconnect: () => void;
  fetchData: (symbol: string) => void;
}

const DataContext = React.createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [data, setData] = React.useState<any>(null);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [error, setError] = React.useState<string | null>(null);
  const [isConnected, setIsConnected] = React.useState<boolean>(false);

  // Simulated connection function
  const connect = () => {
    setLoading(true);
    // Simulate connection delay
    setTimeout(() => {
      setIsConnected(true);
      setLoading(false);
      // Load sample data
      fetchData("NSE_INDEX|Nifty Bank");
    }, 1000);
  };

  // Simulated disconnect function
  const disconnect = () => {
    setIsConnected(false);
    setData(null);
  };

  // Simulated data fetching function
  const fetchData = (symbol: string) => {
    if (!isConnected) return;
    
    setLoading(true);
    setError(null);
    
    // Simulate API call delay
    setTimeout(() => {
      // Sample data structure based on the provided format
      const sampleData = {
        type: "live_feed",
        feeds: {
          "NSE_FO|45450": {
            fullFeed: {
              marketFF: {
                ltpc: {
                  ltp: 213.75,
                  ltt: "1740727891235",
                  ltq: "150",
                  cp: 494.05
                },
                marketLevel: {
                  bidAskQuote: [
                    {
                      bidQ: "75",
                      bidP: 213.45,
                      askQ: "525",
                      askP: 213.9
                    },
                    {
                      bidQ: "225",
                      bidP: 213.3,
                      askQ: "150",
                      askP: 213.95
                    },
                    {
                      bidQ: "150",
                      bidP: 213.25,
                      askQ: "75",
                      askP: 214
                    },
                    {
                      bidQ: "150",
                      bidP: 213.2,
                      askQ: "225",
                      askP: 214.05
                    },
                    {
                      bidQ: "225",
                      bidP: 213.1,
                      askQ: "75",
                      askP: 214.1
                    }
                  ]
                },
                optionGreeks: {
                  delta: 0.4952,
                  theta: -8.4067,
                  gamma: 0.0007,
                  vega: 16.769,
                  rho: 3.8673
                },
                marketOHLC: {
                  ohlc: [
                    {
                      interval: "1d",
                      open: 400,
                      high: 400,
                      low: 208.7,
                      close: 213.75,
                      vol: "779400",
                      ts: "1740681000000"
                    },
                    {
                      interval: "I1",
                      open: 210,
                      high: 212.8,
                      low: 208.7,
                      close: 212.15,
                      vol: "8475",
                      ts: "1740727800000"
                    }
                  ]
                },
                atp: 272.9,
                vtt: "779625",
                oi: 210000,
                iv: 0.131378173828125,
                tbq: 46050,
                tsq: 41850
              }
            }
          }
        },
        currentTs: "1740727891739"
      };
      
      setData(sampleData);
      setLoading(false);
    }, 1000);
  };

  const value = {
    data,
    loading,
    error,
    isConnected,
    connect,
    disconnect,
    fetchData
  };

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
};

export const useDataContext = (): DataContextType => {
  const context = React.useContext(DataContext);
  if (context === undefined) {
    throw new Error('useDataContext must be used within a DataProvider');
  }
  return context;
};