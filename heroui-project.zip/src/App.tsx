import React from 'react';
import { Tabs, Tab, Card, CardBody, Select, SelectItem } from "@heroui/react";
import { Icon } from '@iconify/react';
import { OptionChainBidAsk } from './components/option-chain-bid-ask';
import { OptionChainOIVolume } from './components/option-chain-oi-volume';
import { DataProvider } from './context/data-context';
import { Header } from './components/header';

// List of available symbols
const symbols = [
  { key: "NSE_INDEX|Nifty Bank", label: "BANKNIFTY" },
  { key: "NSE_FO|HDFCBANK", label: "HDFCBANK" },
  { key: "NSE_FO|ICICIBANK", label: "ICICIBANK" },
  { key: "NSE_FO|SBIN", label: "SBIN" },
  { key: "NSE_FO|KOTAKBANK", label: "KOTAKBANK" },
  { key: "NSE_FO|AXISBANK", label: "AXISBANK" }
];

function App() {
  const [selectedSymbol, setSelectedSymbol] = React.useState<string>("NSE_INDEX|Nifty Bank");
  const [selectedTab, setSelectedTab] = React.useState<string>("bid-ask");

  return (
    <DataProvider>
      <div className="min-h-screen bg-background flex flex-col">
        <Header />
        <main className="flex-1 container mx-auto px-4 py-6">
          <Card className="mb-6">
            <CardBody>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="flex items-center gap-2">
                  <Icon icon="lucide:bar-chart-2" className="text-primary text-xl" />
                  <h1 className="text-xl font-semibold">Option Chain Dashboard</h1>
                </div>
                <div className="w-full md:w-72">
                  <Select 
                    label="Select Symbol" 
                    selectedKeys={[selectedSymbol]} 
                    onChange={(e) => setSelectedSymbol(e.target.value)}
                  >
                    {symbols.map((symbol) => (
                      <SelectItem key={symbol.key} value={symbol.key}>
                        {symbol.label}
                      </SelectItem>
                    ))}
                  </Select>
                </div>
              </div>
            </CardBody>
          </Card>

          <Tabs 
            aria-label="Option Chain Tabs" 
            selectedKey={selectedTab} 
            onSelectionChange={setSelectedTab}
            className="mb-6"
          >
            <Tab key="bid-ask" title={
              <div className="flex items-center gap-2">
                <Icon icon="lucide:trending-up" />
                <span>Bid/Ask Analysis</span>
              </div>
            }>
              <OptionChainBidAsk symbol={selectedSymbol} />
            </Tab>
            <Tab key="oi-volume" title={
              <div className="flex items-center gap-2">
                <Icon icon="lucide:bar-chart" />
                <span>OI & Volume</span>
              </div>
            }>
              <OptionChainOIVolume symbol={selectedSymbol} />
            </Tab>
          </Tabs>
        </main>
      </div>
    </DataProvider>
  );
}

export default App;