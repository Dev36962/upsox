/**
 * Format a number with commas as thousands separators
 */
export const formatNumber = (num: number | string): string => {
  if (typeof num === 'string') {
    num = parseFloat(num);
  }
  
  if (isNaN(num)) {
    return '0';
  }
  
  return num.toLocaleString('en-IN');
};

/**
 * Format a timestamp to a readable date/time
 */
export const formatTimestamp = (timestamp: string): string => {
  const date = new Date(parseInt(timestamp));
  return date.toLocaleString();
};
