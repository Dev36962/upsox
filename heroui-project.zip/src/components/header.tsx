import React from 'react';
import { Navbar, NavbarBrand, NavbarContent, Button } from "@heroui/react";
import { Icon } from '@iconify/react';
import { useDataContext } from '../context/data-context';

export const Header: React.FC = () => {
  const { isConnected, connect, disconnect } = useDataContext();

  return (
    <Navbar maxWidth="full" isBordered>
      <NavbarBrand>
        <Icon icon="lucide:bar-chart-4" className="text-primary text-2xl mr-2" />
        <p className="font-bold text-inherit">OptionChain Dashboard</p>
      </NavbarBrand>
      <NavbarContent justify="end">
        <Button
          color={isConnected ? "success" : "primary"}
          variant={isConnected ? "flat" : "solid"}
          startContent={<Icon icon={isConnected ? "lucide:wifi" : "lucide:wifi-off"} />}
          onPress={isConnected ? disconnect : connect}
        >
          {isConnected ? "Connected" : "Connect"}
        </Button>
      </NavbarContent>
    </Navbar>
  );
};