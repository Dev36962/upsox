import React from 'react';
import { Card, CardBody, Table, TableHeader, TableColumn, TableBody, TableRow, TableCell, Spinner } from "@heroui/react";
import { useDataContext } from '../context/data-context';
import { formatNumber } from '../utils/format-utils';

interface OptionChainBidAskProps {
  symbol: string;
}

export const OptionChainBidAsk: React.FC<OptionChainBidAskProps> = ({ symbol }) => {
  const { data, loading } = useDataContext();
  const [optionChainData, setOptionChainData] = React.useState<any[]>([]);

  React.useEffect(() => {
    if (data && data.feeds) {
      // Process data to create option chain rows
      const processedData = processOptionChainData(data.feeds);
      setOptionChainData(processedData);
    }
  }, [data, symbol]);

  // This is a placeholder for data processing logic
  // In a real implementation, this would extract and organize option chain data
  const processOptionChainData = (feeds: any) => {
    // Sample data structure for demonstration
    return [
      {
        strike: 45500,
        ce: {
          ltp: 213.75,
          bidQty: 825,
          bidPrice: 213.45,
          askPrice: 213.9,
          askQty: 975
        },
        pe: {
          ltp: 185.25,
          bidQty: 750,
          bidPrice: 185.10,
          askPrice: 185.40,
          askQty: 825
        }
      },
      {
        strike: 45450,
        ce: {
          ltp: 213.75,
          bidQty: 825,
          bidPrice: 213.45,
          askPrice: 213.9,
          askQty: 975
        },
        pe: {
          ltp: 185.25,
          bidQty: 750,
          bidPrice: 185.10,
          askPrice: 185.40,
          askQty: 825
        }
      },
      {
        strike: 45400,
        ce: {
          ltp: 243.15,
          bidQty: 600,
          bidPrice: 242.80,
          askPrice: 243.25,
          askQty: 750
        },
        pe: {
          ltp: 155.85,
          bidQty: 900,
          bidPrice: 155.60,
          askPrice: 156.10,
          askQty: 675
        }
      },
      {
        strike: 45350,
        ce: {
          ltp: 273.45,
          bidQty: 450,
          bidPrice: 273.10,
          askPrice: 273.65,
          askQty: 600
        },
        pe: {
          ltp: 126.55,
          bidQty: 1050,
          bidPrice: 126.30,
          askPrice: 126.80,
          askQty: 525
        }
      },
      {
        strike: 45300,
        ce: {
          ltp: 304.95,
          bidQty: 375,
          bidPrice: 304.60,
          askPrice: 305.20,
          askQty: 450
        },
        pe: {
          ltp: 98.05,
          bidQty: 1200,
          bidPrice: 97.80,
          askPrice: 98.30,
          askQty: 375
        }
      }
    ];
  };

  // Calculate totals for bid and ask quantities
  const totals = React.useMemo(() => {
    let totalCEBidQty = 0;
    let totalCEAskQty = 0;
    let totalPEBidQty = 0;
    let totalPEAskQty = 0;

    optionChainData.forEach(item => {
      totalCEBidQty += item.ce.bidQty;
      totalCEAskQty += item.ce.askQty;
      totalPEBidQty += item.pe.bidQty;
      totalPEAskQty += item.pe.askQty;
    });

    return {
      totalCEBidQty,
      totalCEAskQty,
      totalPEBidQty,
      totalPEAskQty
    };
  }, [optionChainData]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Spinner size="lg" color="primary" />
      </div>
    );
  }

  return (
    <Card>
      <CardBody>
        <div className="mb-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-2">
          <h2 className="text-lg font-semibold">Bid/Ask Analysis</h2>
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">CE Total Bid:</span>
              <span className="text-sm font-bold text-success">{formatNumber(totals.totalCEBidQty)}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">CE Total Ask:</span>
              <span className="text-sm font-bold text-danger">{formatNumber(totals.totalCEAskQty)}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">PE Total Bid:</span>
              <span className="text-sm font-bold text-success">{formatNumber(totals.totalPEBidQty)}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">PE Total Ask:</span>
              <span className="text-sm font-bold text-danger">{formatNumber(totals.totalPEAskQty)}</span>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <Table aria-label="Option Chain Bid/Ask Data" removeWrapper isStriped>
            <TableHeader>
              <TableColumn className="bg-primary-50 text-center">LTP</TableColumn>
              <TableColumn className="bg-success-50 text-center">Bid Qty</TableColumn>
              <TableColumn className="bg-success-50 text-center">Bid Price</TableColumn>
              <TableColumn className="bg-primary-50 text-center font-bold">STRIKE</TableColumn>
              <TableColumn className="bg-danger-50 text-center">Ask Price</TableColumn>
              <TableColumn className="bg-danger-50 text-center">Ask Qty</TableColumn>
              <TableColumn className="bg-primary-50 text-center">LTP</TableColumn>
            </TableHeader>
            <TableBody>
              {optionChainData.map((item, index) => (
                <TableRow key={index}>
                  <TableCell className="text-center">{formatNumber(item.ce.ltp)}</TableCell>
                  <TableCell className="text-center font-medium text-success">
                    {formatNumber(item.ce.bidQty)}
                  </TableCell>
                  <TableCell className="text-center">{formatNumber(item.ce.bidPrice)}</TableCell>
                  <TableCell className="text-center font-bold bg-primary-50">{item.strike}</TableCell>
                  <TableCell className="text-center">{formatNumber(item.pe.askPrice)}</TableCell>
                  <TableCell className="text-center font-medium text-danger">
                    {formatNumber(item.pe.askQty)}
                  </TableCell>
                  <TableCell className="text-center">{formatNumber(item.pe.ltp)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardBody>
    </Card>
  );
};