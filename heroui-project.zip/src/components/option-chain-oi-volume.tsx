import React from 'react';
import { Card, CardBody, Table, TableHeader, TableColumn, TableBody, TableRow, TableCell, Spinner } from "@heroui/react";
import { useDataContext } from '../context/data-context';
import { formatNumber } from '../utils/format-utils';

interface OptionChainOIVolumeProps {
  symbol: string;
}

export const OptionChainOIVolume: React.FC<OptionChainOIVolumeProps> = ({ symbol }) => {
  const { data, loading } = useDataContext();
  const [optionChainData, setOptionChainData] = React.useState<any[]>([]);

  React.useEffect(() => {
    if (data && data.feeds) {
      // Process data to create option chain rows
      const processedData = processOptionChainData(data.feeds);
      setOptionChainData(processedData);
    }
  }, [data, symbol]);

  // This is a placeholder for data processing logic
  // In a real implementation, this would extract and organize option chain data
  const processOptionChainData = (feeds: any) => {
    // Sample data structure for demonstration
    return [
      {
        strike: 45500,
        ce: {
          ltp: 213.75,
          oi: 210000,
          volume: 78940
        },
        pe: {
          ltp: 185.25,
          oi: 185000,
          volume: 65230
        }
      },
      {
        strike: 45450,
        ce: {
          ltp: 213.75,
          oi: 210000,
          volume: 77940
        },
        pe: {
          ltp: 185.25,
          oi: 185000,
          volume: 65230
        }
      },
      {
        strike: 45400,
        ce: {
          ltp: 243.15,
          oi: 180000,
          volume: 62450
        },
        pe: {
          ltp: 155.85,
          oi: 195000,
          volume: 72340
        }
      },
      {
        strike: 45350,
        ce: {
          ltp: 273.45,
          oi: 150000,
          volume: 48750
        },
        pe: {
          ltp: 126.55,
          oi: 220000,
          volume: 85670
        }
      },
      {
        strike: 45300,
        ce: {
          ltp: 304.95,
          oi: 120000,
          volume: 32560
        },
        pe: {
          ltp: 98.05,
          oi: 250000,
          volume: 96780
        }
      }
    ];
  };

  // Calculate totals for OI and volume
  const totals = React.useMemo(() => {
    let totalCEOI = 0;
    let totalCEVolume = 0;
    let totalPEOI = 0;
    let totalPEVolume = 0;

    optionChainData.forEach(item => {
      totalCEOI += item.ce.oi;
      totalCEVolume += item.ce.volume;
      totalPEOI += item.pe.oi;
      totalPEVolume += item.pe.volume;
    });

    return {
      totalCEOI,
      totalCEVolume,
      totalPEOI,
      totalPEVolume
    };
  }, [optionChainData]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Spinner size="lg" color="primary" />
      </div>
    );
  }

  return (
    <Card>
      <CardBody>
        <div className="mb-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-2">
          <h2 className="text-lg font-semibold">OI & Volume Analysis</h2>
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">CE Total OI:</span>
              <span className="text-sm font-bold text-primary">{formatNumber(totals.totalCEOI)}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">CE Total Volume:</span>
              <span className="text-sm font-bold text-secondary">{formatNumber(totals.totalCEVolume)}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">PE Total OI:</span>
              <span className="text-sm font-bold text-primary">{formatNumber(totals.totalPEOI)}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">PE Total Volume:</span>
              <span className="text-sm font-bold text-secondary">{formatNumber(totals.totalPEVolume)}</span>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <Table aria-label="Option Chain OI/Volume Data" removeWrapper isStriped>
            <TableHeader>
              <TableColumn className="bg-primary-50 text-center">LTP</TableColumn>
              <TableColumn className="bg-primary-100 text-center">OI</TableColumn>
              <TableColumn className="bg-secondary-50 text-center">Volume</TableColumn>
              <TableColumn className="bg-primary-50 text-center font-bold">STRIKE</TableColumn>
              <TableColumn className="bg-primary-100 text-center">OI</TableColumn>
              <TableColumn className="bg-secondary-50 text-center">Volume</TableColumn>
              <TableColumn className="bg-primary-50 text-center">LTP</TableColumn>
            </TableHeader>
            <TableBody>
              {optionChainData.map((item, index) => (
                <TableRow key={index}>
                  <TableCell className="text-center">{formatNumber(item.ce.ltp)}</TableCell>
                  <TableCell className="text-center font-medium">
                    {formatNumber(item.ce.oi)}
                  </TableCell>
                  <TableCell className="text-center">{formatNumber(item.ce.volume)}</TableCell>
                  <TableCell className="text-center font-bold bg-primary-50">{item.strike}</TableCell>
                  <TableCell className="text-center font-medium">
                    {formatNumber(item.pe.oi)}
                  </TableCell>
                  <TableCell className="text-center">{formatNumber(item.pe.volume)}</TableCell>
                  <TableCell className="text-center">{formatNumber(item.pe.ltp)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardBody>
    </Card>
  );
};