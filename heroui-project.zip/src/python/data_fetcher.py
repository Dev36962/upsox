import json
import websocket
import time
import threading
import os
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Global variables
ws = None
connected = False
latest_data = {}
subscribed_symbols = []

# Default symbols to subscribe
DEFAULT_SYMBOLS = [
    "NSE_INDEX|Nifty Bank",
    "NSE_FO|HDFCBANK",
    "NSE_FO|ICICIBANK",
    "NSE_FO|SBIN",
    "NSE_FO|KOTAKBANK",
    "NSE_FO|AXISBANK"
]

def on_message(ws, message):
    """Handle incoming WebSocket messages"""
    global latest_data
    try:
        data = json.loads(message)
        if data.get("type") == "live_feed":
            latest_data = data
            print(f"Received data for {len(data.get('feeds', {}))} instruments")
    except Exception as e:
        print(f"Error processing message: {e}")

def on_error(ws, error):
    """Handle WebSocket errors"""
    print(f"WebSocket error: {error}")

def on_close(ws, close_status_code, close_msg):
    """Handle WebSocket connection close"""
    global connected
    connected = False
    print(f"WebSocket connection closed: {close_status_code} - {close_msg}")

def on_open(ws):
    """Handle WebSocket connection open"""
    global connected
    connected = True
    print("WebSocket connection established")
    subscribe_to_symbols(DEFAULT_SYMBOLS)

def subscribe_to_symbols(symbols):
    """Subscribe to the given symbols"""
    global ws, subscribed_symbols
    
    if not ws or not connected:
        print("WebSocket not connected")
        return False
    
    try:
        # Create subscription message
        subscription_msg = {
            "guid": generate_guid(),
            "method": "sub",
            "data": {
                "mode": "full",
                "instrumentKeys": symbols
            }
        }
        
        # Send subscription request
        ws.send(json.dumps(subscription_msg))
        subscribed_symbols = symbols
        print(f"Subscribed to {len(symbols)} symbols")
        return True
    except Exception as e:
        print(f"Error subscribing to symbols: {e}")
        return False

def generate_guid():
    """Generate a simple GUID for requests"""
    import uuid
    return str(uuid.uuid4()).replace('-', '')[:20]

def start_websocket():
    """Start the WebSocket connection"""
    global ws
    
    # WebSocket connection URL (replace with actual URL)
    ws_url = "wss://your-websocket-endpoint.com/ws"
    
    # Create WebSocket connection
    ws = websocket.WebSocketApp(
        ws_url,
        on_open=on_open,
        on_message=on_message,
        on_error=on_error,
        on_close=on_close
    )
    
    # Start WebSocket connection in a separate thread
    wst = threading.Thread(target=ws.run_forever)
    wst.daemon = True
    wst.start()
    
    # Wait for connection to establish
    timeout = 5
    start_time = time.time()
    while not connected and time.time() - start_time < timeout:
        time.sleep(0.1)
    
    return connected

def stop_websocket():
    """Stop the WebSocket connection"""
    global ws, connected
    if ws:
        ws.close()
        ws = None
        connected = False
        return True
    return False

# API Routes
@app.route('/api/connect', methods=['POST'])
def connect():
    """Connect to the WebSocket server"""
    if connected:
        return jsonify({"status": "already_connected"})
    
    success = start_websocket()
    return jsonify({"status": "connected" if success else "connection_failed"})

@app.route('/api/disconnect', methods=['POST'])
def disconnect():
    """Disconnect from the WebSocket server"""
    success = stop_websocket()
    return jsonify({"status": "disconnected" if success else "not_connected"})

@app.route('/api/subscribe', methods=['POST'])
def subscribe():
    """Subscribe to symbols"""
    data = request.json
    symbols = data.get('symbols', DEFAULT_SYMBOLS)
    
    if not connected:
        return jsonify({"status": "not_connected", "error": "WebSocket not connected"}), 400
    
    success = subscribe_to_symbols(symbols)
    return jsonify({
        "status": "subscribed" if success else "subscription_failed",
        "symbols": symbols
    })

@app.route('/api/data', methods=['GET'])
def get_data():
    """Get the latest data"""
    if not connected:
        return jsonify({"status": "not_connected", "error": "WebSocket not connected"}), 400
    
    return jsonify({
        "status": "success",
        "data": latest_data,
        "subscribed_symbols": subscribed_symbols,
        "timestamp": int(time.time() * 1000)
    })

@app.route('/api/status', methods=['GET'])
def get_status():
    """Get the connection status"""
    return jsonify({
        "connected": connected,
        "subscribed_symbols": subscribed_symbols
    })

if __name__ == "__main__":
    # Start the Flask server
    app.run(host='0.0.0.0', port=5000, debug=True)
