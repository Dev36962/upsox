# Option Chain Data Fetcher

This Python script connects to a WebSocket server to fetch live option chain data and provides a REST API for the frontend to consume.

## Setup

1. Install the required dependencies:
```
pip install -r requirements.txt
```

2. Update the WebSocket URL in `data_fetcher.py` to point to your data source.

3. Run the server:
```
python data_fetcher.py
```

## API Endpoints

- `POST /api/connect` - Connect to the WebSocket server
- `POST /api/disconnect` - Disconnect from the WebSocket server
- `POST /api/subscribe` - Subscribe to symbols (provide a JSON body with `symbols` array)
- `GET /api/data` - Get the latest data
- `GET /api/status` - Get the connection status

## Data Format

The script expects data in the following format:

```json
{
  "type": "live_feed",
  "feeds": {
    "NSE_FO|45450": {
      "fullFeed": {
        "marketFF": {
          "ltpc": {
            "ltp": 213.75,
            "ltt": "1740727891235",
            "ltq": "150",
            "cp": 494.05
          },
          "marketLevel": {
            "bidAskQuote": [
              {
                "bidQ": "75",
                "bidP": 213.45,
                "askQ": "525",
                "askP": 213.9
              }
            ]
          },
          "optionGreeks": {
            "delta": 0.4952,
            "theta": -8.4067,
            "gamma": 0.0007,
            "vega": 16.769,
            "rho": 3.8673
          },
          "marketOHLC": {
            "ohlc": [
              {
                "interval": "1d",
                "open": 400,
                "high": 400,
                "low": 208.7,
                "close": 213.75,
                "vol": "779400",
                "ts": "1740681000000"
              }
            ]
          },
          "atp": 272.9,
          "vtt": "779625",
          "oi": 210000,
          "iv": 0.131378173828125,
          "tbq": 46050,
          "tsq": 41850
        }
      }
    }
  },
  "currentTs": "1740727891739"
}
```

## Subscription Format

When subscribing to symbols, the script sends a request in this format:

```json
{
  "guid": "13syxu852ztodyqncwt0",
  "method": "sub",
  "data": {
    "mode": "full",
    "instrumentKeys": ["NSE_INDEX|Nifty Bank"]
  }
}
```
